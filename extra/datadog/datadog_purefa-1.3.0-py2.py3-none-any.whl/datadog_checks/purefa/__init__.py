from .__about__ import __version__
from .purefa import PureFACheck

__all__ = ['__version__', 'PureFACheck']
